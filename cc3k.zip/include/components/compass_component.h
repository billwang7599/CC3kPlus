#ifndef COMPASS_COMPONENT_H
#define COMPASS_COMPONENT_H

#include "component.h"

class CompassComponent : public Component
{};

#endif // COMPASS_COMPONENT_H
