
#ifndef BARRIER_SUIT_COMPONENT_H
#define BARRIER_SUIT_COMPONENT_H

#include "component.h"

class BarrierSuitComponent : public Component {};

#endif