#ifndef ALL_POSITIVE_COMPONENT_H
#define ALL_POSITIVE_COMPONENT_H

#include "component.h"

class AllPositiveComponent : public Component {
};
#endif // ALL_POSITIVE_COMPONENT_H
