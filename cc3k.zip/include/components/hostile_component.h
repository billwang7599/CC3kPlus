#ifndef HOSTILE_COMPONENT_H
#define HOSTILE_COMPONENT_H

#include "component.h"

class HostileComponent : public Component
{};


#endif // HOSTILE_COMPONENT_H
