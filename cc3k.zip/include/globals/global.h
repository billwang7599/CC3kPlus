#ifndef GLOBAL_H
#define GLOBAL_H


#include <string>
#include <vector>
#include "entities/entity.h"

extern std::vector<std::string> actionMessage;
extern std::vector<std::string> seenPotions;
#endif // GLOBAL_H
