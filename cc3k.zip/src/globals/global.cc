#include "globals/global.h"

std::vector<std::string> actionMessage = {"Player has spawned!"};
std::vector<std::string> seenPotions;