#ifndef STAIRS_COMPONENT_H
#define STAIRS_COMPONENT_H

#include "component.h"

class StairsComponent : public Component
{};

#endif // STAIRS_COMPONENT_H
