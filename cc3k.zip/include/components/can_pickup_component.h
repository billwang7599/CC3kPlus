#ifndef CAN_PICKUP_COMPONENT_H
#define CAN_PICKUP_COMPONENT_H

#include "component.h"

class CanPickupComponent : public Component
{};

#endif // CAN_PICKUP_COMPONENT_H
